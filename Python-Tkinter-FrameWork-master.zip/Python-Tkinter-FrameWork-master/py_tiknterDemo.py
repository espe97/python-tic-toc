from tkinter import *
#from tkinter import messagebox
window=Tk()
window.title("Welcome to The Gaming world ")
window.geometry("500x500")

window.mainloop()


